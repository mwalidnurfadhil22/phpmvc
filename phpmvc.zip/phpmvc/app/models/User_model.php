<?php 

class User_model{
	private $nama = 'Fadhil';

	public function getUser(){
		return $this->nama;
	}
}